// Aggregator stub: the settings page has been modularized.
// See js/settings-*.js files for feature-specific logic.
// This file remains to preserve the original script reference.

console.debug('Settings modules loaded.');

